import os
import sys
import pathlib
import threading
import webbrowser
sys.path.append(os.path.abspath(str(pathlib.Path(__file__).parent.absolute()) + "/../"))


from app import app

if __name__ == '__main__':
    # start server and open browser tab
    port = 81
    url = "http://127.0.0.1:{0}".format(port)
    # open url after server has started
    threading.Timer(1.5, lambda: webbrowser.open(url) ).start()

    app.run(debug=True, port=port) # debug=False if url is opening multiple times
