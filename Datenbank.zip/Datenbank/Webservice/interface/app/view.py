from app import app
from flask import render_template, request, send_file, redirect, Blueprint, url_for, make_response, Response
from io import BytesIO, StringIO
import time
import requests
import base64
import pandas as pd
import sys
import json
from Query.Awf_Query import *
from Query.Awf_DB_Setup import setupDatabase

mainFilters = ["Lebenszyklusphase", "BIM-Ziel", "Klasse"]
hasData = False

@app.route("/", methods=["GET", "POST"])
def home():
    return render_template("start.html")

# Laden der Awfs zum auswählen/filtern
@app.route("/awf-finder", methods=["GET"])
def queryAwfList():
    global mainFilters
    global hasData
    # print("Initial hasData:", hasData, file=sys.stderr)
    try:
        conn = connectDb()
        filterList = getFilterList(conn)
        optFilterList = list( filter(lambda x: x[1] not in mainFilters, filterList) )
        classGroupList = getClassGroupList(conn)
        classGroupList1 = list( filter(lambda x: x[4] == mainFilters[0], classGroupList) )
        classGroupList2 = list( filter(lambda x: x[4] == mainFilters[1], classGroupList) )
        classGroupList3 = list( filter(lambda x: x[4] == mainFilters[2], classGroupList) )
        classGroupList4 = list( filter(lambda x: x[4] not in mainFilters, classGroupList) )
        classGroupLists = (classGroupList1, classGroupList2, classGroupList3, classGroupList4)
        classList = getClassList(conn)
        # print("classGroupList1:", classGroupList1, flush=True)
        # print("classGroupList2:", classGroupList2, flush=True)
        # print("classGroupList3:", classGroupList3, flush=True)
        # print("classGroupList4:", classGroupList4, flush=True)
        active = {
            "selClassGroup1": "",
            "selClass1": "",
            "selClassGroup2": "",
            "selClass2": "",
            "selClassGroup3": "",
            "selClass3": "",
            "selFilter4": "",
            "selClassGroup4": "",
            "selClass4": ""
        }

        awfList = getAwfList(conn, None, False)
        if awfList:
            newList = list()
            for awf in awfList:
                entry = list()
                for val in awf:
                    entry.append(val)
                entry.append(hasPart1(conn, awf[0]))
                entry.append(hasPart2(conn, awf[0]))
                entry.append(hasPart3(conn, awf[0]))
                print(entry, flush=True)
                newList.append(entry)
            hasData = True
    except:
        print("Datenbank konnte nicht verbunden werden.", file=sys.stderr)
    finally:
        disconnectDb(conn)
        if hasData:
            return render_template(
                "awf-finder.html", 
                hasData=True, 
                awfList=newList, 
                filterList=optFilterList, 
                classGroupLists=classGroupLists, 
                classList=classList, 
                active=active
            )
        else:
            return render_template(
                "awf-finder.html", 
                hasData=False, 
                active=active
            ) 


@app.route("/awf-filter", methods=["GET"])
def queryAwfListFiltered():
    global mainFilters
    global hasData
    # print("hasData:", hasData, file=sys.stderr)
    conn = connectDb()

    filterList = getFilterList(conn)
    optFilterList = list( filter(lambda x: x[1] not in mainFilters, filterList) )
    classGroupList = getClassGroupList(conn)
    classGroupList1 = list( filter(lambda x: x[4] == mainFilters[0], classGroupList) )
    classGroupList2 = list( filter(lambda x: x[4] == mainFilters[1], classGroupList) )
    classGroupList3 = list( filter(lambda x: x[4] == mainFilters[2], classGroupList) )
    classGroupList4 = list( filter(lambda x: x[4] not in mainFilters, classGroupList) )
    classGroupLists = (classGroupList1, classGroupList2, classGroupList3, classGroupList4)
    classList = getClassList(conn)
    print("classGroupList1:", classGroupList1, flush=True)
    print("classGroupList2:", classGroupList2, flush=True)
    print("classGroupList3:", classGroupList3, flush=True)
    print("classGroupList4:", classGroupList4, flush=True)

    selFilter4 = request.args.get("selFilter4") # GET -> args, POST -> form
    selClassGroup1 = request.args.get("selClassGroup1")
    selClassGroup2 = request.args.get("selClassGroup2")
    selClassGroup3 = request.args.get("selClassGroup3")
    selClassGroup4 = request.args.get("selClassGroup4")
    selClass1 = request.args.getlist("selClass1")
    selClass2 = request.args.getlist("selClass2")
    selClass3 = request.args.getlist("selClass3")
    selClass4 = request.args.getlist("selClass4")
    active = {
        "selClassGroup1": selClassGroup1,
        "selClass1": selClass1,
        "selClassGroup2": selClassGroup2,
        "selClass2": selClass2,
        "selClassGroup3": selClassGroup3,
        "selClass3": selClass3,
        "selFilter4": selFilter4,
        "selClassGroup4": selClassGroup4,
        "selClass4": selClass4
    }
    # print("classes:", file=sys.stdout)
    # print(selClasses, file=sys.stdout)

    # Awf-Liste auf Basis der selektierten Klassen abrufen
    allSelClassList = list()
    classIdList = list()
    for i in range(1, 4):
        if not isinstance(active["selClass"+str(i)], str):
            for cForm in active["selClass"+str(i)]:
                for cDb in classList:
                    if cDb[1] in cForm:
                        classIdList.append(cDb[0])
        else:
            for cDb in classList:
                if cDb[1] == active["selClass"+str(i)]:
                    classIdList.append(cDb[0])
    print("classIdList:", classIdList, flush=True)
    awfList = getAwfList(conn, classIdList, True)

    newList = list()
    for awf in awfList:
        entry = list()
        for val in awf:
            entry.append(val)
        entry.append(hasPart1(conn, awf[0]))
        entry.append(hasPart2(conn, awf[0]))
        entry.append(hasPart3(conn, awf[0]))
        newList.append(entry)

    disconnectDb(conn)
    if hasData:
        return render_template(
            "awf-finder.html", 
            hasData=True, 
            awfList=newList, 
            filterList=optFilterList, 
            classGroupLists=classGroupLists, 
            classList=classList, 
            active=active
        )
    else:
        return render_template(
            "awf-finder.html", 
            hasData=False, 
            awfList=newList, 
            filterList=optFilterList, 
            classGroupLists=classGroupLists, 
            classList=classList, 
            active=active
        )


@app.route("/setup-database", methods=["POST"])
def setupDatabaseTables():
    print("request.files:", request.files, flush=True)
    if request.files:
        # Tabelle gegeben -> DB aus Tabelle füllen
        print("Found request.files", flush=True)
        dbTableFile = request.files.get("dbTableFile")
    else:
        # Keine Tabelle -> leere DB erstellen
        print("Didnt find request.files", flush=True)
        dbTableFile = None
    conn = connectDb()
    setupDatabase(conn, dbTableFile)
    disconnectDb(conn)
    return queryAwfList() # Übersicht neu laden

@app.route("/return-database", methods=["GET"])
def getDatabaseTable():
    conn = connectDb()
    tablesDict = getAllDbTables(conn)
    disconnectDb(conn)
    dfList = list(tablesDict.values())
    sheetList = list(tablesDict.keys())
    output = BytesIO()
    with pd.ExcelWriter(output, engine='xlsxwriter', mode="w") as writer:
        for sheetName in tablesDict:
            df = tablesDict[sheetName]
            df.to_excel(writer, sheet_name=sheetName, index=False)
    output.seek(0)
    return send_file(output, download_name="Awf-Db-Export.xlsx", as_attachment=True)

# Laden der Awfs zum auswählen/filtern
@app.route("/awf-reader", methods=["GET"])
def openAwf():
    conn = connectDb()

    awfList = getAwfList(conn, None, False) # für Auswahlliste

    awfId = None # default
    if "btnSelectAwf" in request.args: # GET -> args, POST -> form
        awfName = request.args.get("selAwfName")
        for tpl in awfList:
            if tpl[1] == awfName:
                awfId = tpl[0]
                break
    else:
        for name in request.args:
            if "open_awf" in name:
                awfId = int(name[8:])
                break
    if awfId:
        awfData = getAwfData(conn, awfId) # individueller Datensatz
        classData = getPart1(conn, awfId)
        processData = getPart2(conn, awfId)
        processOverview = {}
        processDetails = list()
        for entry in processData:
            if entry[4] in processOverview:
                processOverview[entry[4]].append(entry[2])
            else:
                processOverview[entry[4]] = [entry[2]]
            # Aufgabe, Verantwortlichkeit, Dokumente, In-/Outputs, IVS
            processDetails.append( (entry[1], entry[2], entry[3], entry[4], entry[5], entry[6], entry[7], entry[8]) )
        fileData = getPart3(conn, awfId)
        # print("processOverview", processOverview, file=sys.stderr)
        disconnectDb(conn)
        return render_template("awf-reader.html", awfList=awfList, loadAwf=True, awfData=awfData, classData=classData, processOverview=processOverview, processDetails=processDetails, fileData=fileData)
    else:
        disconnectDb(conn)
        return render_template("awf-reader.html", awfList=awfList, loadAwf=False)

@app.route("/awf-editor", methods=["GET", "POST"])
def editAwf():
    conn = connectDb()
    awfList = getAwfList (conn, None, False) # für Auswahlliste

    if request.method == "POST":
        awfId = None # default
        # print("request.form", request.form, file=sys.stderr)
        if "btnNewAwf" in request.form: # GET -> args, POST -> form
            optionsData = getEditorOptions(conn) # Daten für Dropdowns
            return render_template("awf-editor.html", awfList=awfList, loadAwf=False, newAwf=True, optionsData=optionsData)

        if "btnSelectAwf" in request.form: # GET -> args, POST -> form
            awfName = request.form.get("selAwfName")
            # print("awfName", awfName, file=sys.stderr)
            for tpl in awfList:
                if tpl[1] == awfName:
                    awfId = tpl[0]
                    break
        if "btnEdit" in request.form: # GET -> args, POST -> form
            awfName = request.form.get("iptAwfName")
            # print("awfName", awfName, file=sys.stderr)
            for tpl in awfList:
                if tpl[1] == awfName:
                    awfId = tpl[0]
                    break
        else:
            for name in request.form:
                if "open_awf" in name:
                    awfId = int(name[8:])
                    break
        # print("awfId", awfId, file=sys.stderr)
        if awfId:
            awfData = getAwfData(conn, awfId) # individueller Datensatz
            classData = getPart1(conn, awfId)
            processData = getPart2(conn, awfId)
            processOverview = {}
            processDetails = list()
            for entry in processData:
                if entry[4] in processOverview: # Aufgabenliste je Verantwortlichkeit
                    processOverview[entry[4]].append(entry[2])
                else:
                    processOverview[entry[4]] = [entry[2]]
                # Aufgabe (ID+Bez), Verantwortlichkeit (ID+Bez), Dokumente, Inputs, Output, IVS
                processDetails.append( (entry[1], entry[2], entry[3], entry[4], entry[5], entry[6], entry[7], entry[8]) )

            imgData = getPart2Img(conn, awfId)
            fileData = getPart3(conn, awfId)
            # print("processOverview", processOverview, file=sys.stderr)
            indvData = [awfData, classData, processOverview, processDetails, imgData, fileData] # Daten des gewählten AwF
            optionsData = getEditorOptions(conn) # Daten für Dropdowns
            disconnectDb(conn)
            return render_template("awf-editor.html", awfList=awfList, loadAwf=True, newAwf=False, optionsData=optionsData, indvData=indvData)

    disconnectDb(conn)
    return render_template("awf-editor.html", awfList=awfList, loadAwf=False, newAwf=False)

def getEditorOptions(conn):
    filterList = getFilterList(conn)
    classGroupList = getClassGroupList(conn)
    classList = getClassList(conn)
    roleList = getRoleList(conn)
    inOutputList = getInOutputList(conn)
    ivsList = getIvsList(conn)
    return [filterList, classGroupList, classList, roleList, inOutputList, ivsList]

@app.route("/awf-write", methods=["POST"])
def writeAwfToDb():
    conn = connectDb()
    print("request.form", request.form, file=sys.stderr)

    # Anwendungsfall Basis
    errStr = "Eingabefehler! {} wird zum Erstellen eines Awf vorausgesetzt."
    awfId = request.form.get("awfId") # kann leer sein -> neuer Awf
    bezeichnung = request.form.get("awfBezeichnung")
    if not bezeichnung: raise Exception(errStr.format("Bezeichnung"))
    beschreibung = request.form.get("awfBeschreibung")
    if not beschreibung: raise Exception(errStr.format("Beschreibung"))
    outputs = request.form.get("awfOutputs")
    if not outputs: raise Exception(errStr.format("Lieferleistung/Outputs"))
    inputs = request.form.get("awfInputs")
    if not inputs: raise Exception(errStr.format("Inputs"))
    abgrenzung = request.form.get("awfAbgrenzung")
    if not abgrenzung: raise Exception(errStr.format("Abgrenzung"))
    voraussetzung = request.form.get("awfVoraussetzung")
    if not voraussetzung: raise Exception(errStr.format("Voraussetzung/Rahmenbedingung"))
    dataTuple = (bezeichnung, beschreibung, inputs, outputs, abgrenzung, voraussetzung)
    awfId = writeAwfData(conn, awfId, dataTuple)

    # Part 1
    classList = list()
    i = 1
    while True:
        clGr = request.form.get("selClassGroup{}".format(i))
        cl = request.form.get("selClass{}".format(i))
        i += 1
        if not clGr or not cl:
            break
        else:
            clGr = clGr.replace("[Global] ", "")
            classList.append((clGr, cl))
    writePart1(conn, awfId, classList)

    # Part 2
    processData = list()
    i = 1
    while True:
        przBezeichnung = request.form.get("przBezeichnung{}".format(i))
        przVerantwortlichkeit = request.form.get("selRole{}".format(i))
        przDokumente = request.form.get("przDokumente{}".format(i))
        # print(przBezeichnung, przVerantwortlichkeit, przDokumente, file=sys.stderr)
        if not przBezeichnung or not przVerantwortlichkeit:
            break
        przInputList = list()
        j = 1
        while True:
            przInputBezeichnung = request.form.get("selInput{}_{}".format(i, j))
            # print("przInputBezeichnung", przInputBezeichnung, file=sys.stderr)
            przInputBeschreibung = request.form.get("iptInputDesc{}_{}".format(i, j))
            # print("przInputBeschreibung", przInputBeschreibung, file=sys.stderr)
            j += 1
            if not przInputBezeichnung:
                break
            elif "input_empty" not in przInputBezeichnung:
                # przInputBeschreibung = przInputBeschreibung ? przInputBeschreibung : "" # ist mindestens leerer String
                przInputList.append((przInputBezeichnung, przInputBeschreibung))
        przOutputBezeichnung = request.form.get("selOutput{}".format(i))
        przOutputBeschreibung = request.form.get("iptOutputDesc{}".format(i))
        przIvsList = list()
        j = 1
        while True:
            przIvsBezeichnung = request.form.get("selIvs{}_{}".format(i, j))
            przIvsBim = request.form.get("iptIvsBimEquiv{}_{}".format(i, j))
            przIvsBeschreibung = request.form.get("iptIvsDesc{}_{}".format(i, j))
            j += 1
            if not przIvsBezeichnung or not przIvsBim:
                break
            elif "ivs_empty" not in przIvsBezeichnung:
                przIvsList.append((przIvsBezeichnung, przIvsBim, przIvsBeschreibung))
        process = (przBezeichnung, przVerantwortlichkeit, przDokumente, przInputList, przOutputBezeichnung, przOutputBeschreibung, przIvsList)
        # print("TEILPROZESS:", process, file=sys.stderr)
        processData.append(process)
        i += 1

    iptPdId = request.form.get("iptPdId")
    iptPdName = request.form.get("iptPdName")
    iptPdUrl = request.form.get("iptPdUrl")
    iptIpId = request.form.get("iptIpId")
    iptIpName = request.form.get("iptIpName")
    iptIpUrl = request.form.get("iptIpUrl")
    iptTdId = request.form.get("iptTdId")
    iptTdName = request.form.get("iptTdName")
    iptTdUrl = request.form.get("iptTdUrl")
    print("request.files:", request.files, file=sys.stderr)
    if request.files:
        imgPd = request.files.get("iptPdFile")
        imgIp = request.files.get("iptIpFile")
        imgTd = request.files.get("iptTdFile")
    else:
        imgPd = None
        imgIp = None
        imgTd = None
    data1 = (iptPdId, iptPdName, iptPdUrl, imgPd)
    data2 = (iptIpId, iptIpName, iptIpUrl, imgIp)
    data3 = (iptTdId, iptTdName, iptTdUrl, imgTd)
    imageData = (data1, data2, data3)
    writePart2(conn, awfId, processData, imageData)

    # Part 3
    if request.form.get("loinMode") == "New":
        iptLoinId = None
    else:
        iptLoinId = request.form.get("iptLoinId")
    iptLoinName = request.form.get("iptLoinName")
    iptLoinUrl = request.form.get("iptLoinUrl")
    if request.form.get("checkerMode") == "New":
        iptCheckerId = None
    else:
        iptCheckerId = request.form.get("iptCheckerId")
    iptCheckerName = request.form.get("iptCheckerName")
    iptCheckerUrl = request.form.get("iptCheckerUrl")
    if request.files:
        fileLoin = request.files.get("iptLoinFile")
        fileChecker = request.files.get("iptCheckerFile")
    else:
        fileLoin = None
        fileChecker = None
    loinData = (iptLoinId, iptLoinName, iptLoinUrl, fileLoin)
    checkerData = (iptCheckerId, iptCheckerName, iptCheckerUrl, fileChecker)
    iptCheckerDesc = request.form.get("checkerDesc")
    fileData = (loinData, checkerData, iptCheckerDesc)
    writePart3(conn, awfId, fileData)

    # Reset page
    awfList = getAwfList(conn, None, False) # für Auswahlliste
    # conn.commit()
    disconnectDb(conn)
    return render_template("awf-editor.html", awfList=awfList, loadAwf=False, newAwf=False)

@app.route("/download", methods=["POST"])
def sendFileFromDb():
    conn = connectDb()
    print("request.form download", request.form, file=sys.stderr)
    val = request.form.get("btnDownloadFile")
    fileId = int(val.split("_")[1])
    fileTuple = getFileFromDb(conn, fileId)
    disconnectDb(conn)
    if val.split("_")[0] == "loin":
        filename = "LOIN-Tabelle%s" %fileTuple[2]
    else:
        filename = "Prüftabelle%s" %fileTuple[2]
    if fileTuple[2] in ("jpg", "jpeg", "png", "bmp", "gif"):
        mimetype = "image/%s" %fileTuple[2]
    else:
        mimetype = "application/%s" %fileTuple[2]
    return send_file(BytesIO(fileTuple[1]), download_name=filename)