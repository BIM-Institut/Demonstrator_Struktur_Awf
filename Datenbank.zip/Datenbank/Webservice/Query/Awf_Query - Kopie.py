import psycopg2
import pandas as pd
import numpy as np
import time
import sys
import os.path
import base64
import re

# Datenbankverbindung aufbauen
def connectDb():
    dir = os.path.dirname(__file__)
    i = dir.find("\\Webservice")
    dir = os.path.dirname(__file__)[:i] # Unterordner abschneiden
    configFilePath = dir + '\\config.txt'
    with open(configFilePath, encoding='utf8') as f:
        for line in f:
            i = line.find("=")+1 # Startindex von Wert
            if "dbname=" in line:
                dbname = line[i:].strip()
            elif "user=" in line:
                user = line[i:].strip()
            elif "password=" in line:
                password = line[i:].strip()
            else:
                continue
    print("Config file read.")

    print("Connect database...")
    try:
        conn = psycopg2.connect(dbname=dbname, user=user, host='localhost', password=password)
        print("Connection to database established.", file=sys.stdout)
    except:
        raise Exception("Connection to database failed.")
    conn.set_client_encoding('UTF8')
    return conn

# Datenbankverbindung schließen
def disconnectDb(conn):
    conn.close()
    print("Connection to database closed.", file=sys.stdout)
    sys.stdout.flush()

# Namensliste der angelegten Tabellen
def getTableNames(conn):
    cursor = conn.cursor()
    cursor.execute("""SELECT table_name FROM information_schema.tables 
        WHERE table_schema NOT IN ('information_schema', 'pg_catalog') AND table_type = 'BASE TABLE'""")
    selectList = cursor.fetchall()
    cursor.close()
    tableNames = list()
    # for tuple in selectList:
    #     tableNames.append(tuple[0])
    return sorted(tableNames, key=str.lower)

# Ganzen Tabelleninhalt holen
def getTableData(conn, tableName):
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM %s;" %tableName)
    selectList = cursor.fetchall()
    cursor.close()
    return selectList

def getAllDbTables(conn):
    cursor = conn.cursor()
    # Tabellennamen holen
    cursor.execute("""SELECT table_name FROM information_schema.tables 
        WHERE table_schema NOT IN ('information_schema', 'pg_catalog') AND table_type = 'BASE TABLE'""")
    tableNames = cursor.fetchall()
    # Tabellen abrufen
    dfMap = {}
    for tpl in tableNames:
        name = tpl[0]
        # print("table name:", name, file=sys.stderr)
        # Spaltennamen
        cursor.execute("SELECT * FROM " + name + " LIMIT 0")
        colList = [desc[0] for desc in cursor.description]
        # print("colList:", colList, file=sys.stderr)
        # Inhalt
        cursor.execute("SELECT * FROM " + name + ";")
        data = cursor.fetchall()
        # print("data:", data, file=sys.stderr)
        if not data:
            line = list()
            for col in colList:
                line.append("")
            data.append(line)
        # Dataframe zusammenbauen
        df = pd.DataFrame(np.array(data), columns=colList)
        # DataFrame mit Typ speichern
        dfMap[name] = df
    cursor.close()
    return dfMap


# ---------------------------------------------------------------------------
# Queries der Übersichtsseite
# ---------------------------------------------------------------------------

# Liste der Filtersystematiken bei Seitenaufruf
def getFilterList(conn):
    cursor = conn.cursor()
    cursor.execute("SELECT id, bezeichnung FROM Filtersystematik;")
    # cursor.execute("SELECT id, bezeichnung FROM Klassifikationssystematik;")
    selectList = cursor.fetchall()
    cursor.close()
    # for entry in selectList:
    #     print(entry, file=sys.stderr)
    return sorted(selectList, key=lambda a: a[1]) # sort by bezeichnung

# Liste der Filtersystematiken bei Seitenaufruf
def getClassGroupList(conn):
    cursor = conn.cursor()
    sql = """SELECT s.id, s.bezeichnung, s.id_filtersystematik, s.ist_global, f.bezeichnung FROM Klassifikationssystematik s 
            INNER JOIN Filtersystematik f ON s.id_filtersystematik = f.id;"""
    cursor.execute(sql)
    selectList = cursor.fetchall()
    cursor.close()
    twistedList = list()
    for entry in selectList: # ist_global für Sortierung umdrehen
        # print(entry, file=sys.stdout)
        twistedList.append( (entry[0], entry[1], entry[2], entry[3] == False, entry[4]) )
    sorted(twistedList, key=lambda a: (a[2], a[3], a[1]) ) # sort by filtersys, !ist_global, bezeichnung
    sortedList = list()
    for entry in twistedList:
        # print(entry, file=sys.stdout)
        sortedList.append( (entry[0], entry[1], entry[2], entry[3] == False, entry[4]) )
    return sortedList

# Liste der Filtersystematiken bei Seitenaufruf
def getClassList(conn):
    cursor = conn.cursor()
    sql = """SELECT k.id, k.bezeichnung, k.id_klassifikationssystematik, s.bezeichnung FROM Klassifikation k 
            INNER JOIN Klassifikationssystematik s ON k.id_klassifikationssystematik = s.id;"""
    cursor.execute(sql)
    selectList = cursor.fetchall()
    cursor.close()
    # for entry in selectList:
    #     print(entry, file=sys.stdout)
    return sorted(selectList, key=lambda a: (a[2], a[1]) ) # sort by systematik and bezeichnung

# Liste der Anwendungsfälle bei Seitenaufruf, filterbar durch Klassifikation.id
def getAwfList (conn, classList):
    cursor = conn.cursor()
    if classList:
        sql = """SELECT id, bezeichnung, beschreibung, inputs, outputs, abgrenzung, voraussetzung FROM Anwendungsfall a 
                INNER JOIN Match_Awf_Klassifikation m ON m.id_anwendungsfall = a.id 
                WHERE m.id_klassifikation = ANY(%s);"""
        if isinstance(classList, int):
            cursor.execute(sql, (classList,))
        else:
            cursor.execute(sql, (classList,))
    else:
        sql = "SELECT id, bezeichnung, beschreibung, inputs, outputs, abgrenzung, voraussetzung FROM Anwendungsfall;"
        cursor.execute(sql)
    selectList = cursor.fetchall()
    cursor.close()
    # for entry in selectList:
    #     print(entry, file=sys.stdout)
    return sorted(selectList, key=lambda awf: awf[1]) # sort by bezeichnung

def getClasses(conn, awfId):
    cursor = conn.cursor()
    cursor.execute("""SELECT m.id_anwendungsfall, a.bezeichnung, m.id_klassifikation, k.id_klassifikationssystematik, s.id_filtersystematik FROM Match_Awf_Klassifikation m 
        INNER JOIN Anwendungsfall a ON m.id_anwendungsfall = a.id 
        INNER JOIN Klassifikation k ON m.id_klassifikation = k.id 
        INNER JOIN Klassifikationssystematik s ON k.id_klassifikationssystematik = s.id 
        WHERE m.id_anwendungsfall = %d;"""%awfId)
    selectList = cursor.fetchall()
    cursor.close()
    return sorted(selectList, key=lambda awf: awf[1]) # sort by bezeichnung

def hasPart1 (conn, awfId):
    cursor = conn.cursor()
    # Ein Anwendungsfall muss mindestens jeweils eine Klassifikation aus der Filtersystematik Lebenzyklusphase und BIM-Ziel haben
    cursor.execute("""SELECT m.id_anwendungsfall, m.id_klassifikation, f.bezeichnung FROM Match_Awf_Klassifikation m 
        INNER JOIN Klassifikation k ON m.id_klassifikation = k.id 
        INNER JOIN Klassifikationssystematik s ON k.id_klassifikationssystematik = s.id 
        INNER JOIN Filtersystematik f ON s.id_filtersystematik = f.id 
        WHERE m.id_anwendungsfall = %d AND f.bezeichnung = 'Lebenzyklusphase';"""%awfId)
    phase = cursor.fetchall()
    cursor.execute("""SELECT m.id_anwendungsfall, m.id_klassifikation, f.bezeichnung FROM Match_Awf_Klassifikation m 
        INNER JOIN Klassifikation k ON m.id_klassifikation = k.id 
        INNER JOIN Klassifikationssystematik s ON k.id_klassifikationssystematik = s.id 
        INNER JOIN Filtersystematik f ON s.id_filtersystematik = f.id 
        WHERE m.id_anwendungsfall = %d AND f.bezeichnung = 'BIM-Ziel';"""%awfId)
    ziel = cursor.fetchall()
    cursor.close()
    if phase and ziel:
        return True
    else:
        return False

def hasPart2 (conn, awfId):
    cursor = conn.cursor()
    # Ein Anwendungsfall muss mindestens eine Aufgabe haben
    cursor.execute( "SELECT m.id_anwendungsfall, m.id_aufgabe_auspraegung FROM Match_Awf_Aufgabe_Auspraegung m WHERE m.id_anwendungsfall = %d;"%awfId )
    selectList = cursor.fetchall()
    if not selectList:
        return False
    # Eine Aufgabe muss mindestens einen IVS und einen Input/Output haben
    for task in selectList:
        taskId = task[1]
        cursor.execute( "SELECT id FROM IVS_Auspraegung WHERE id_aufgabe_auspraegung = %d"%taskId )
        ivsList = cursor.fetchall()
        cursor.execute( "SELECT id_aufgabe_auspraegung FROM Match_Aufgabe_Ausp_InOutput WHERE id_aufgabe_auspraegung = %d"%taskId )
        ioList = cursor.fetchall()
        if not ivsList or not ioList:
            return False
    cursor.close()
    return True

def hasPart3 (conn, awfId):
    cursor = conn.cursor()
    sql = "SELECT id FROM Anwendungsfall a WHERE id = %d AND id_loindatei IS NOT NULL AND (pruefbeschreibung IS NOT NULL OR id_pruefdatei IS NOT NULL);"%awfId
    cursor.execute(sql)
    selectList = cursor.fetchall()
    cursor.close()
    if selectList:
        return True
    else:
        return False

# ---------------------------------------------------------------------------
# Queries der AwF-Ansichtsseite, nur für einzelne AwFs gebaut
# ---------------------------------------------------------------------------

def getAwfData (conn, awfId):
    cursor = conn.cursor()
    sql = "SELECT id, bezeichnung, beschreibung, inputs, outputs, abgrenzung, voraussetzung FROM Anwendungsfall WHERE id = %d;"%awfId
    cursor.execute(sql)
    selectList = cursor.fetchall()
    cursor.close()
    modifiedList = list()
    for entry in selectList:
        i = 0
        start = 0
        strList = list()
        while i >= 0:
            try:
                i = entry[2].index(r"Anmerkung \d:", start+1)
                strList.append( entry[2][start:i] )
            except ValueError:
                i = -1
                strList.append( entry[2][start:] )
            start = i
        newEntry = (entry[0], entry[1], strList, entry[3], entry[4], entry[5], entry[6])
        # print(newEntry, file=sys.stdout)
        modifiedList.append(newEntry)
    return modifiedList

def getPart1 (conn, awfId):
    cursor = conn.cursor()
    cursor.execute("""SELECT m.id_anwendungsfall, m.id_klassifikation, k.bezeichnung, s.bezeichnung, f.bezeichnung FROM Match_Awf_Klassifikation m 
        INNER JOIN Klassifikation k ON m.id_klassifikation = k.id 
        INNER JOIN Klassifikationssystematik s ON k.id_klassifikationssystematik = s.id 
        INNER JOIN Filtersystematik f ON s.id_filtersystematik = f.id 
        WHERE m.id_anwendungsfall = %d;"""%awfId)
    selectList = cursor.fetchall()
    cursor.close()
    # for entry in selectList:
    #     print(entry, file=sys.stderr)
    return selectList

def getPart2 (conn, awfId):
    cursor = conn.cursor()

    # Aufgaben + Ausprägung
    cursor.execute("""SELECT m.id_anwendungsfall, a.id, a.bezeichnung, v.id, v.bezeichnung, aa.mitgelt_dokumente FROM Match_Awf_Aufgabe_Auspraegung m 
        INNER JOIN Aufgabe_Auspraegung aa ON m.id_aufgabe_auspraegung = aa.id 
        INNER JOIN Aufgabe a ON aa.id_aufgabe = a.id 
        INNER JOIN Verantwortlichkeit v ON aa.id_verantwortlichkeit = v.id 
        WHERE m.id_anwendungsfall = %d;"""%awfId)
    taskList = list()
    for tpl in cursor.fetchall():
        taskData = list(tpl)
        aaId = taskData[1]
        # Inputs und Output
        cursor.execute("""SELECT mio.id_aufgabe_auspraegung, mio.id_in_output, mio.ist_input, io.bezeichnung, io.beschreibung FROM Match_Aufgabe_Ausp_InOutput mio 
            INNER JOIN In_Output io ON mio.id_in_output = io.id 
            WHERE mio.ist_input IS TRUE AND mio.id_aufgabe_auspraegung = %d;"""%aaId)
        inputList = cursor.fetchall()
        taskData.append(inputList)
        # Inputs und Output
        cursor.execute("""SELECT mio.id_aufgabe_auspraegung, mio.id_in_output, mio.ist_input, io.bezeichnung, io.beschreibung FROM Match_Aufgabe_Ausp_InOutput mio 
            INNER JOIN In_Output io ON mio.id_in_output = io.id 
            WHERE mio.ist_input IS FALSE AND mio.id_aufgabe_auspraegung = %d;"""%aaId)
        outputList = cursor.fetchall()
        taskData.append(outputList)
        # Informationsverarbeitungschritte + Ausprägung
        cursor.execute("""SELECT aa.id, ia.id, i.bezeichnung, ia.beschreibung, ia.bim_auspraegung, i.id FROM Aufgabe_Auspraegung aa 
            INNER JOIN IVS_Auspraegung ia ON ia.id_aufgabe_auspraegung = aa.id 
            INNER JOIN IVS i ON ia.id_ivs = i.id 
            WHERE aa.id = %d;"""%aaId)
        ivsList = cursor.fetchall()
        taskData.append(ivsList)
        taskList.append(taskData)
    cursor.close()
    # for entry in taskList:
    #     print(entry, file=sys.stderr)
    return taskList

def getPart2Img(conn, awfId):
    cursor = conn.cursor()
    sql = "SELECT id_prozessdiagramm, id_interaktionsplan, id_transaktionsdiagramm FROM Anwendungsfall WHERE id = %d;"%awfId
    cursor.execute(sql)
    idList = cursor.fetchall()[0]
    imgDataList = list()
    for imgId in idList:
        if imgId:
            sql = "SELECT id, bezeichnung, url, encode(datei, 'base64'), dateityp FROM Datei a WHERE id = %d;"%imgId
            cursor.execute(sql)
            imgData = cursor.fetchall()[0]
            imgDataList.append((imgData[0], imgData[1], imgData[2], imgData[3], imgData[4]))
        else:
            imgDataList.append(None)
    cursor.close()
    # for img in imgDataList:
    #     if img:
    #         print("image:", img[0], img[1], img[2], img[3], file=sys.stderr)
    #     else:
    #         print("image: none", file=sys.stderr)
    return imgDataList

def getPart3 (conn, awfId):
    cursor = conn.cursor()
    sql = """SELECT a.id_loindatei, d1.bezeichnung, d1.url, d1.datei, a.pruefbeschreibung, a.id_pruefdatei, d2.bezeichnung, d2.url, d2.datei FROM Anwendungsfall a 
        INNER JOIN Datei d1 ON a.id_loindatei = d1.id 
        INNER JOIN Datei d2 ON a.id_pruefdatei = d2.id 
        WHERE a.id = %d;"""%awfId
    cursor.execute(sql)
    selectList = cursor.fetchall()
    cursor.close()
    for entry in selectList:
        print("image:", entry[0], entry[1], entry[4], entry[5], entry[6], file=sys.stderr)
    return selectList

def getFileFromDb(conn, fileId):
    cursor = conn.cursor()
    sql = "SELECT id, datei, dateityp FROM Datei WHERE id = %d;"%fileId
    cursor.execute(sql)
    selectList = cursor.fetchall()
    cursor.close()
    if selectList:
        print("file:", selectList[0], file=sys.stderr)
        return selectList[0]

# ---------------------------------------------------------------------------
# Queries der AwF-Editorseite
# ---------------------------------------------------------------------------

def getRoleList(conn):
    cursor = conn.cursor()
    sql = "SELECT id, bezeichnung FROM Verantwortlichkeit;"
    cursor.execute(sql)
    selectList = cursor.fetchall()
    cursor.close()
    # for entry in selectList:
    #     print(entry, file=sys.stdout)
    return sorted(selectList, key=lambda a: a[1] ) # sort by bezeichnung

def getInOutputList(conn):
    cursor = conn.cursor()
    sql = "SELECT id, bezeichnung, beschreibung FROM In_Output;"
    cursor.execute(sql)
    selectList = cursor.fetchall()
    cursor.close()
    # for entry in selectList:
    #     print(entry, file=sys.stdout)
    return sorted(selectList, key=lambda a: a[1] ) # sort by bezeichnung

def getIvsList(conn):
    cursor = conn.cursor()
    sql = "SELECT id, bezeichnung FROM IVS;"
    cursor.execute(sql)
    selectList = cursor.fetchall()
    cursor.close()
    # for entry in selectList:
    #     print(entry, file=sys.stdout)
    return sorted(selectList, key=lambda a: a[1] ) # sort by bezeichnung

# ---------------------------------------------------------------------------
# Einfügen der Awf-Daten von Editorseite
# ---------------------------------------------------------------------------

def writeAwfData(conn, awfId, dataTuple):
    adaptSequenceStartValues(conn) # ID-Zähler setzen
    if len(dataTuple) == 6:
        cursor = conn.cursor()
        if awfId: # vorhandenen Awf modifizieren
            sql = "UPDATE Anwendungsfall SET bezeichnung = %s, beschreibung = %s, inputs = %s, outputs = %s, abgrenzung = %s, voraussetzung = %s WHERE id = %s;"
            cursor.execute(sql, (dataTuple + (awfId,)) )
            print("Awf (ID =", awfId, ") wurde angepasst", file=sys.stderr)
        else:
            sql = "INSERT INTO Anwendungsfall (bezeichnung, beschreibung, inputs, outputs, abgrenzung, voraussetzung) VALUES (%s, %s, %s, %s, %s, %s) RETURNING id;"
            cursor.execute(sql, dataTuple)
            awfId = cursor.fetchall()[0][0]
            print("Awf (ID =", awfId, ") wurde erstellt", file=sys.stderr)
        cursor.close()
        return awfId;
    else:
        raise Exception("Datensatz ungültig. Es wurde nicht die erforderliche Anzahl an Einträgen übergeben. (Erforderlich: 6, erhalten: %d)")

# Startwerte der ID Serial-Sequenzen setzen, damit sie nicht bei 1 starten sondern hinter der größten ID
def adaptSequenceStartValues(conn):
    setSequenceStartValue(conn, "Filtersystematik", "id")
    setSequenceStartValue(conn, "Klassifikationssystematik", "id")
    setSequenceStartValue(conn, "Klassifikation", "id")
    setSequenceStartValue(conn, "Datei", "id")
    setSequenceStartValue(conn, "Anwendungsfall", "id")
    setSequenceStartValue(conn, "Verantwortlichkeit", "id")
    setSequenceStartValue(conn, "In_Output", "id")
    setSequenceStartValue(conn, "Aufgabe", "id")
    setSequenceStartValue(conn, "Aufgabe_Auspraegung", "id")
    setSequenceStartValue(conn, "IVS", "id")
    setSequenceStartValue(conn, "IVS_Auspraegung", "id")

def setSequenceStartValue(conn, tableName, colName):
    cursor = conn.cursor()
    sql1 = "SELECT pg_get_serial_sequence('{}', '{}');".format(tableName, colName) # find sequence name
    cursor.execute(sql1)
    seqName = cursor.fetchall()[0][0]
    sql2 = "SELECT MAX({}) FROM {};".format(colName, tableName) # get max value
    cursor.execute(sql2)
    maxId = cursor.fetchall()[0][0]
    # print(tableName, "- seqName", seqName, "maxId", maxId, file=sys.stderr)
    sql = "SELECT setval('{}', ({}));".format(seqName, maxId) # set sequence start value
    cursor.execute(sql)
    cursor.close()

def writePart1(conn, awfId, classList):
    # print("--- writePart1() ---", file=sys.stderr)
    cursor = conn.cursor()
    # alte Matches des Awf löschen
    sql = "DELETE FROM Match_Awf_Klassifikation WHERE id_anwendungsfall='%s';"%awfId
    cursor.execute(sql)
    # Liste der selClassGroup# durchlaufen und Daten von selClass mit Awf matchen und speichern
    for cl in classList:
        # print("classList entry", cl[0], cl[1], file=sys.stderr)
        sql = "SELECT id FROM Klassifikationssystematik WHERE bezeichnung='%s';"%cl[0]
        cursor.execute(sql)
        clGrId = cursor.fetchall()[0][0]
        # print("clGrId", clGrId, file=sys.stderr)
        sql = "SELECT id FROM Klassifikation WHERE bezeichnung='%s' AND id_klassifikationssystematik='%s'"%(cl[1], clGrId)
        cursor.execute(sql)
        clId = cursor.fetchall()[0][0]
        # print("clId", clId, file=sys.stderr)
        sql = "INSERT INTO Match_Awf_Klassifikation (id_anwendungsfall, id_klassifikation) VALUES (%s, %s);"%(awfId, clId)
        cursor.execute(sql)
        conn.commit()
    cursor.close()

def writePart2(conn, awfId, processData, imageData):
    cursor = conn.cursor()
    # alte Matches des Awf löschen
    sql = "DELETE FROM Match_Awf_Aufgabe_Auspraegung WHERE id_anwendungsfall='%s';"%awfId
    cursor.execute(sql)
    # Liste der selClassGroup# durchlaufen und Daten von selClass mit Awf matchen und speichern
    for prz in processData:
        # print("SCHREIBE TEILPROZESS", prz, file=sys.stderr)
        # Verantwortlichkeit ID holen
        sql = "SELECT id FROM Verantwortlichkeit WHERE bezeichnung='%s';"%prz[1]
        cursor.execute(sql)
        result = cursor.fetchall()
        if result:
            roleId = result[0][0]
        else:
            break
        # print("roleId", roleId, file=sys.stderr)
        # Aufgabe erstellen
        sql = "INSERT INTO Aufgabe (bezeichnung) VALUES (%s) RETURNING id;"
        cursor.execute(sql, (prz[0], ))
        result = cursor.fetchall()
        if result:
            taskId = result[0][0]
        else:
            break
        # print("taskId", taskId, file=sys.stderr)
        # Aufgabe Ausprägung erstellen
        sql = "INSERT INTO Aufgabe_Auspraegung (id_aufgabe, id_verantwortlichkeit, mitgelt_dokumente) VALUES (%s, %s, %s) RETURNING id;"
        cursor.execute(sql, (taskId, roleId, prz[2]))
        result = cursor.fetchall()
        if result:
            specTaskId = result[0][0]
        else:
            break
        # print("specTaskId", specTaskId, file=sys.stderr)
        # Aufgabe Ausprägung mit Awf matchen
        sql = "INSERT INTO Match_Awf_Aufgabe_Auspraegung (id_anwendungsfall, id_aufgabe_auspraegung) VALUES (%s, %s);"
        cursor.execute(sql, (awfId, specTaskId))
        # Alte Matches von Inputs ud Output mit Aufgabe löschen
        sql = "DELETE FROM Match_Aufgabe_Ausp_InOutput WHERE id_aufgabe_auspraegung='%s';"%specTaskId
        cursor.execute(sql)
        # Inputs
        for ipt in prz[3]:
            # wenn beschreibung==None, dann Standard
            sql = "SELECT id FROM In_Output WHERE bezeichnung='%s' AND beschreibung='%s';"%(ipt[0], ipt[1])
            cursor.execute(sql)
            result = cursor.fetchall()
            # print("try iptId", result, file=sys.stderr)
            if not result:
                # Input erstellen
                sql = "INSERT INTO In_Output (bezeichnung, beschreibung) VALUES (%s, %s) RETURNING id;"
                cursor.execute(sql, (ipt[0], ipt[1]))
                iptId = cursor.fetchall()[0][0]
                # print("set iptId", iptId, file=sys.stderr)
            else:
                iptId = result[0][0]
            # Match_Aufgabe_Ausp_InOutput erstellen
            sql = "INSERT INTO Match_Aufgabe_Ausp_InOutput (id_aufgabe_auspraegung, id_in_output, ist_input) VALUES (%s, %s, %s);"
            cursor.execute(sql, (specTaskId, iptId, True))
        # Output
        sql = "SELECT id FROM In_Output WHERE bezeichnung='%s' AND beschreibung='%s';"%(prz[4], prz[5])
        cursor.execute(sql)
        result = cursor.fetchall()
        # print("try optId", result, file=sys.stderr)
        if not result:
            # Input erstellen
            sql = "INSERT INTO In_Output (bezeichnung, beschreibung) VALUES (%s, %s) RETURNING id;"
            cursor.execute(sql, (prz[4], prz[5]))
            optId = cursor.fetchall()[0][0]
            # print("set optId", optId, file=sys.stderr)
        else:
            optId = result[0][0]
        # Match_Aufgabe_Ausp_InOutput erstellen
        sql = "INSERT INTO Match_Aufgabe_Ausp_InOutput (id_aufgabe_auspraegung, id_in_output, ist_input) VALUES (%s, %s, %s);"
        cursor.execute(sql, (specTaskId, optId, False))
        # Informationsverarbeitungsschritte (IVS)
        for ivs in prz[6]:
            sql = "SELECT id FROM IVS WHERE bezeichnung='%s';"%ivs[0]
            cursor.execute(sql)
            result = cursor.fetchall()
            if result:
                ivsId = result[0][0]
            else:
                continue
            # print("ivsId", ivsId, file=sys.stderr)
            # IVS Ausprägung erstellen
            sql = "INSERT INTO IVS_Auspraegung (id_ivs, bim_auspraegung, beschreibung, id_aufgabe_auspraegung) VALUES (%s, %s, %s, %s) RETURNING id;"
            cursor.execute(sql, (ivsId, ivs[1], ivs[2], specTaskId))
            result = cursor.fetchall()
            if result:
                ivsAusprId = result[0][0]
            else:
                break
            # print("ivsAusprId", ivsAusprId, file=sys.stderr)
    
    # Prozessgrafiken in DB schreiben
    fileIds = list()
    for img in imageData:
        if img[0]: #id
            imgId = img[0]
            # print("has imgId", imgId, file=sys.stderr)
        else:
            # Datei-Eintrag erstellen, falls Anforderungen erfüllt
            if img[1] and (img[2] or img[3]):
                sql = "INSERT INTO Datei (bezeichnung, url, datei, dateityp) VALUES (%s, %s, %s, %s) RETURNING id;"
                filename, extension = os.path.splitext(img[3].filename)
                extension = extension.strip(".").lower()
                fileStream = img[3].read()
                cursor.execute(sql, (img[1], img[2], fileStream, extension))
                imgId = cursor.fetchall()[0][0]
                # print("new imgId", imgId, file=sys.stderr)
            else:
                # print("no img", file=sys.stderr)
                imgId = None
        fileIds.append(imgId)
    sql = "UPDATE Anwendungsfall SET id_prozessdiagramm = %s, id_interaktionsplan = %s, id_transaktionsdiagramm = %s WHERE id = %s;"
    cursor.execute(sql, (fileIds[0], fileIds[1], fileIds[2], awfId) )
    print("Abbildungen wurden Awf (ID =", awfId, ") hinzugefügt", file=sys.stderr)
    conn.commit()
    cursor.close()

def writePart3(conn, awfId, fileData):
    cursor = conn.cursor()
    # alte Matches des Awf löschen
    sql = "DELETE FROM Match_Awf_Klassifikation WHERE id_anwendungsfall='%s';"%awfId
    cursor.execute(sql)
    # Dateianhänge in DB schreiben
    loin = fileData[0]
    if loin[0]: #id
        loinId = loin[0]
        print("has loinId", loinId, file=sys.stderr)
    else:
        # Datei-Eintrag erstellen
        if loin[1] and (loin[2] or loin[3]):
            sql = "INSERT INTO Datei (bezeichnung, url, datei, dateityp) VALUES (%s, %s, %s, %s) RETURNING id;"
            filename, extension = os.path.splitext(loin[3].filename)
            fileStream = loin[3].read()
            cursor.execute(sql, (loin[1], loin[2], fileStream, extension))
            loinId = cursor.fetchall()[0][0]
            print("new loinId", loinId, file=sys.stderr)
        else:
            print("no loin file", file=sys.stderr)
            loinId = None
    checker = fileData[1]
    if checker[0]: #id
        checkerId = checker[0]
        print("has checkerId", checkerId, file=sys.stderr)
    else:
        # Datei-Eintrag erstellen
        if checker[1] and (checker[2] or checker[3]):
            sql = "INSERT INTO Datei (bezeichnung, url, datei, dateityp) VALUES (%s, %s, %s, %s) RETURNING id;"
            filename, extension = os.path.splitext(loin[3].filename)
            fileStream = base64.b64encode(checker[3].read())
            cursor.execute(sql, (checker[1], checker[2], fileStream, extension))
            checkerId = cursor.fetchall()[0][0]
            print("new checkerId", checkerId, file=sys.stderr)
        else:
            print("no checker file", file=sys.stderr)
            checkerId = None
    sql = "UPDATE Anwendungsfall SET id_loindatei = %s, id_pruefdatei = %s, pruefbeschreibung = %s WHERE id = %s;"
    cursor.execute(sql, (loinId, checkerId, fileData[2], awfId) )
    print("Anhangdateien wurden Awf (ID =", awfId, ") hinzugefügt", flush=True)
    conn.commit()
    cursor.close()




# ---------------------------------------------------------------------------
# Alte Queries (Archiv)
# ---------------------------------------------------------------------------


# Abfrage: Typ + LoI -> Attribute
def dbQueryTypeLoi(conn, typeList, loi):
    cursor = conn.cursor()
    if "Alle" in typeList:
        cursor.execute("SELECT bezeichnung FROM Typ;")
        selectList = cursor.fetchall()
        typeList = list()
        for sel in selectList:
            typeList.append(sel[0])
    dataList = list()
    for type in typeList:
        sqlTableCols = "t.bezeichnung, t.klDin276, t.klIfc, a.bezeichnung, m.pset, m.loi_min, a.format, m.einheit, m.infoLieferung, m.infoAufnahme"
        sqlSelect = "SELECT " + sqlTableCols + " FROM Matching m "
        sqlJoin1 = "INNER JOIN Attribut a ON m.attributId = a.id "
        sqlJoin2 = "INNER JOIN Typ t ON m.typId = t.id "
        sqlJoin = sqlJoin1 + sqlJoin2
        sqlSelectType = "SELECT id FROM Typ WHERE bezeichnung='" + type + "'"
        sqlWhere = "WHERE m.typId=(" + sqlSelectType + ") AND m.loi_min<='" + loi + "';"
        sql = sqlSelect + sqlJoin + sqlWhere
        cursor.execute(sql)
        dataList += cursor.fetchall()
    # Dataframe zusammenbauen
    colList = ["Typ", "DIN 276", "IFC Entität", "Attribut", "Pset", "LoI_min", "Format", "Einheit", "IL", "IA"]
    df = pd.DataFrame(np.array(dataList), columns=colList)
    cursor.close()
    return df

# Abfrage: Attribut + LoI -> Typen
def dbQueryPropLoi(conn, propList, loi):
    cursor = conn.cursor()
    if "Alle" in propList:
        cursor.execute("SELECT bezeichnung FROM Attribut;")
        selectList = cursor.fetchall()
        propList = list()
        for sel in selectList:
            propList.append(sel[0])
    dataList = list()
    for prop in propList:
        sqlTableCols = "a.bezeichnung, t.bezeichnung, m.loi_min, t.klDin276, t.klIfc, k.bezeichnung, k.arbeitsbereich, k.log" + loi
        sqlSelect = "SELECT " + sqlTableCols + " FROM Matching m "
        sqlJoin = "INNER JOIN Typ t ON m.typId = t.id "
        sqlJoin += "INNER JOIN Kategorie k ON t.kategorieId = k.id "
        sqlJoin += "INNER JOIN Attribut a ON m.attributId = a.id "
        sqlSelectProp = "SELECT id FROM Attribut WHERE bezeichnung='" + prop + "'"
        sqlWhere = "WHERE m.attributId=(" + sqlSelectProp + ") AND m.loi_min<='" + loi + "';"
        sql = sqlSelect + sqlJoin + sqlWhere
        cursor.execute(sql)
        dataList += cursor.fetchall()
    if len(dataList) == 0:
        raise Exception("Query has no result. Please try again.")
    colList = ["Attribut", "Typ", "LoI_min", "DIN 276", "IFC", "Kategorie", "Arbeitsbereich", "LoG" + loi]
    df = pd.DataFrame(np.array(dataList), columns=colList)
    cursor.close()
    return df

# Abfrage: Excel-Output für mvdXML des ILC Projekts mit folgenden Spalten:
# Prozessbezeichnung E3 (leer), Prozessverantwortlicher (leer),
# DIN 276, IFC, Property Set, Merkmal BUW, Einheit, Datentyp, Notwendig (immer Yes),
# gleich, ungleich, größer, größergleich, kleiner, kleinergleich (alle leer)
def dbQueryMvdTemplate(conn, typeList, loi):
    cursor = conn.cursor()
    if "Alle" in typeList:
        cursor.execute("SELECT bezeichnung FROM Typ;")
        selectList = cursor.fetchall()
        typeList = list()
        for sel in selectList:
            typeList.append(sel[0])
    dataList = list()
    for type in typeList:
        sqlTableCols = "t.bezeichnung, t.klDin276, t.klIfc, m.pset, a.bezeichnung, m.einheit, a.format"
        sqlSelect = "SELECT " + sqlTableCols + " FROM Matching m "
        sqlJoin1 = "INNER JOIN Attribut a ON m.attributId = a.id "
        sqlJoin2 = "INNER JOIN Typ t ON m.typId = t.id "
        sqlJoin = sqlJoin1 + sqlJoin2
        sqlSelectType = "SELECT id FROM Typ WHERE bezeichnung='" + type + "'"
        sqlWhere = "WHERE m.typId=(" + sqlSelectType + ") AND m.loi_min<='" + loi + "';"
        sql = sqlSelect + sqlJoin + sqlWhere
        cursor.execute(sql)
        dataList += cursor.fetchall()
    # Dataframe zusammenbauen
    colList = ["Typ", "DIN 276", "IFC", "Property Set", "Merkmal BUW", "Einheit", "Datentyp"]
    df = pd.DataFrame(np.array(dataList), columns=colList)
    # Bezeichnung der Datentypen anpassen
    df = df.replace(to_replace={"Label":"String","Text":"String","Datum":"String","Zahl":"Real","Ganzzahl":"Integer","Dezimalzahl":"Real"}) # Entity, Enum nicht verwendet
    # Leere Spalten am Anfang und Ende ergänzen
    df.insert(loc=0, column="Prozessbezeichnung E3", value=['' for i in range(df.shape[0])])
    df.insert(loc=1, column="Prozessverantwortlicher", value=['' for i in range(df.shape[0])])
    colAdd = ["Notwendig", "gleich", "ungleich", "größer", "größergleich", "kleiner", "kleinergleich"]
    i = df.shape[1]
    for col in colAdd:
        if col == "Notwendig":
            df.insert(loc=i, column=col, value=['Yes' for i in range(df.shape[0])])
        else:
            df.insert(loc=i, column=col, value=['' for i in range(df.shape[0])])
        i += 1
    cursor.close()
    return df

# Abfrage: Excel Output für Revit-Import via CAD-Parser
# Spalten Typ, IfcEntity, Pset, Attribut, Einheit, Format, "gleich"
def dbQueryRevitImportData(conn, typeList, loi):
    cursor = conn.cursor()
    if "Alle" in typeList:
        cursor.execute("SELECT bezeichnung FROM Typ;")
        selectList = cursor.fetchall()
        typeList = list()
        for sel in selectList:
            typeList.append(sel[0])
    dataList = list()
    for type in typeList:
        sqlTableCols = "t.bezeichnung, t.klIfc, m.pset, a.bezeichnung, m.einheit, a.format"
        sqlSelect = "SELECT " + sqlTableCols + " FROM Matching m "
        sqlJoin1 = "INNER JOIN Attribut a ON m.attributId = a.id "
        sqlJoin2 = "INNER JOIN Typ t ON m.typId = t.id "
        sqlJoin = sqlJoin1 + sqlJoin2
        sqlSelectType = "SELECT id FROM Typ WHERE bezeichnung='" + type + "'"
        sqlWhere = "WHERE m.typId=(" + sqlSelectType + ") AND m.loi_min>'100';"
        sql = sqlSelect + sqlJoin + sqlWhere
        cursor.execute(sql)
        dataList += cursor.fetchall()
    # Dataframe zusammenbauen
    colList = ["Component", "IfcEntity", "Pset", "Property", "Einheit", "Value Type"] # wird erweitert
    df = pd.DataFrame(np.array(dataList), columns=colList)
    # Bezeichnung der Datentypen anpassen
    df = df.replace(to_replace={"Label":"Enum","Text":"String","Datum":"Entity","Zahl":"Real","Ganzzahl":"Integer","Dezimalzahl":"Real"})
    # Spalten ohne DB-Inhalt ergänzen
    df.insert(loc=4, column="GUID (Property)", value=['' for i in range(df.shape[0])])
    df.insert(loc=1, column="GUID (Component)", value=['' for i in range(df.shape[0])])
    df.insert(loc=df.shape[1], column="gleich", value=['' for i in range(df.shape[0])])
    df.loc[df["Value Type"] == "Boolean", "gleich"] = "True"
    df.loc[df["Value Type"].isin(["Real", "Integer"]), "gleich"] = "0"

    cursor.close()
    return df

# Abfrage: Excel Output für die Export-Einstellungen mit Spalten Typ, IfcEntity, Pset, Attribut, Format
def dbQueryPsetExportConfig(conn, typeList, loi):
    cursor = conn.cursor()
    if "Alle" in typeList:
        cursor.execute("SELECT bezeichnung FROM Typ;")
        selectList = cursor.fetchall()
        typeList = list()
        for sel in selectList:
            typeList.append(sel[0])
    newDf = pd.DataFrame(columns=["PSet", "Property", "Datentyp", "Ifc"])
    print(newDf.columns, file=sys.stderr)
    for type in typeList:
        # Daten aus Matchings für Typ holen
        sqlTableCols = "t.bezeichnung, t.klIfc, m.pset, a.bezeichnung, a.format"
        sqlSelect = "SELECT " + sqlTableCols + " FROM Matching m "
        sqlJoin1 = "INNER JOIN Attribut a ON m.attributId = a.id "
        sqlJoin2 = "INNER JOIN Typ t ON m.typId = t.id "
        sqlJoin = sqlJoin1 + sqlJoin2
        sqlSelectType = "SELECT id FROM Typ WHERE bezeichnung='" + type + "'"
        sqlWhere = "WHERE m.typId=(" + sqlSelectType + ") AND m.loi_min<='" + loi + "';"
        sql = sqlSelect + sqlJoin + sqlWhere
        cursor.execute(sql)
        # Dataframe zusammenbauen
        colList = ["Typ", "Ifc", "PSet", "Property", "Datentyp"]
        df = pd.DataFrame(np.array(cursor.fetchall()), columns=colList)
        # Liste der Psets filtern
        psets = df["PSet"].unique()
        for pset in psets:
            # Pset-Kopfzeile in DF schreiben
            psetRow = pd.Series(["PropertySet:", str(pset), "|", str(df.loc[1, "Ifc"]) ], index=["PSet", "Property", "Datentyp", "Ifc"])
            #print(psetRow, file=sys.stderr)
            newDf = newDf.append(psetRow, ignore_index=True)
            # Attribut von Pset abfragen
            props = df.loc[df["PSet"] == pset, ["Property", "Datentyp"]]
            # Spalten anpassen und einfügen
            props.insert(loc=0, column="PSet", value=['' for i in range(props.shape[0])])
            props.insert(loc=props.shape[1], column="Ifc", value=['' for i in range(props.shape[0])])
            #print(props.head(), file=sys.stderr)
            newDf = newDf.append(props, ignore_index=True)
    # Bezeichnung der Datentypen anpassen
    newDf = newDf.replace(to_replace={"Label":"Enum","Text":"String","Datum":"Entity","Zahl":"Real","Ganzzahl":"Integer","Dezimalzahl":"Real"})
    #print(newDf.head(), file=sys.stderr)

    cursor.close()
    return newDf

# Abfrage: Tabellen zur Attribut-Regelprüfung im Solibri Model Checker
def dbQueryPsetSolibriRules(conn, typeList, loi):
    cursor = conn.cursor()
    if "Alle" in typeList:
        cursor.execute("SELECT bezeichnung FROM Typ;")
        selectList = cursor.fetchall()
        typeList = list()
        for sel in selectList:
            typeList.append(sel[0])
    dfMap = {}
    for type in typeList:
        sqlTableCols = "t.bezeichnung, m.pset, a.bezeichnung, a.format"
        sqlSelect = "SELECT " + sqlTableCols + " FROM Matching m "
        sqlJoin1 = "INNER JOIN Attribut a ON m.attributId = a.id "
        sqlJoin2 = "INNER JOIN Typ t ON m.typId = t.id "
        sqlJoin = sqlJoin1 + sqlJoin2
        sqlSelectType = "SELECT id FROM Typ WHERE bezeichnung='" + type + "'"
        sqlWhere = "WHERE m.typId=(" + sqlSelectType + ") AND m.loi_min>'100';"
        sql = sqlSelect + sqlJoin + sqlWhere
        cursor.execute(sql)
        data = cursor.fetchall()
        #print(data, file=sys.stderr)
        if not data: # nichts gefunden
            continue
        # Dataframe zusammenbauen
        colList = ["Component", "Property Set", "Property", "Value Type"] # wird erweitert
        df = pd.DataFrame(np.array(data), columns=colList)
        # Bezeichnung der Datentypen anpassen
        df = df.replace(to_replace={"Label":"Choices","Text":"Text","Datum":"Checked Property","Zahl":"Numeric","Ganzzahl":"Numeric","Dezimalzahl":"Numeric"})
        # Leere Spalten am Anfang und Ende ergänzen
        df.insert(loc=3, column="Value Exists", value=['Must exist' for i in range(df.shape[0])])
        colAdd = ["Color", "Visualize Only", "Text Values", "Unit", "Operator", "Numeric Value", "Operator 2", "Numeric Value 2", "Divided By"]
        i = df.shape[1]
        for col in colAdd:
            df.insert(loc=i, column=col, value=['' for i in range(df.shape[0])])
            i += 1
        #print(df.head(), file=sys.stderr)
        # DataFrame mit Typ speichern
        dfMap[type[:31]] = df # String auf 31 Zeichen beschränken (Excel Sheet Namen)

    cursor.close()
    return dfMap

# Abfrage: Alle erzeugten Tabellen der Datenbank
def dbQueryAllTables(conn):
    cursor = conn.cursor()
    # Tabellennamen holen
    sql = "SELECT table_name FROM information_schema.tables WHERE table_schema NOT IN ('information_schema', 'pg_catalog') AND table_type = 'BASE TABLE'"
    cursor.execute(sql)
    tableNames = cursor.fetchall()
    # Tabellen abrufen
    dfMap = {}
    for tuple in tableNames:
        name = tuple[0]
        # Spaltennamen abrufen
        cursor.execute("Select * FROM " + name + " LIMIT 0")
        colList = [desc[0] for desc in cursor.description]
        sql = "SELECT * FROM " + name
        cursor.execute(sql)
        data = cursor.fetchall()
        # Dataframe zusammenbauen
        df = pd.DataFrame(np.array(data), columns=colList)
        # DataFrame mit Typ speichern
        dfMap[name] = df

    cursor.close()
    return dfMap
