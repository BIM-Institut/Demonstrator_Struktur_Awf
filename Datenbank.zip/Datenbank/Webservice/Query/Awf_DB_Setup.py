import urllib.request # file downloads
import psycopg2 # db connection
import pandas as pd # data frames + install openpyxl package
import numpy as np # stuff
import time
import os
import sys
from psycopg2.extensions import register_adapter, AsIs
psycopg2.extensions.register_adapter(np.int64, psycopg2._psycopg.AsIs)

# Einlesen der Tabellenblätter eines Exceldokuments
def getDataFrameList(filePath, sheetNames):
    dfList = list()
    for sheetName in sheetNames:
        dataFrame = pd.read_excel(filePath, sheet_name = sheetName)
        dfList.append(dataFrame)
        # print(dataFrame.head())
    return dfList

#
def getDfItem(df, sourceName, row, key):
    try: # KeyError: '400' -> Keine Spalte mit dieser Bezeichnung vorhanden
        item = df.loc[row, key]
        return item
    except KeyError:
        print("ERROR: Bei Tabellenblatt", sourceName, "fehlt Spaltenbezeichnung", key)

# Pairings von ID mit Liste von semikolon-getrennten IDs bauen
def getMatchList(id1, refStr):
    matchList = list()
    if refStr:
        if type(refStr) == str and ";" in refStr:
            refList = item.split(";")
        else: 
            refList = [refStr]

        for ref in refList:
            match = (id1, int(ref))
            matchList.append(match)
    return matchList

# Überzählige Leerzeichen, Umbrüche etc in String entfernen
def cleanStr(s):
    try:
        s = " ".join(s.split()) # removes "all whitespace characters (space, tab, newline, return, formfeed)" 
        # s = s.strip() # Leerzeichen, Tabs, Umbrüche am Anfang und Ende entfernen
        # s = s.replace("  ", " ") # Doppelte Leerzeichen reduzieren
        # s = s.replace("\t", " ") # Doppelte Leerzeichen reduzieren
        # s = s.replace("- \n", "") # Umbrüche im Wort entfernen
        # s = s.replace("-\n", "") # Umbrüche im Wort entfernen
        # s = s.replace("\n", "") # Verbleibende Umbrüche entfernen
    except AttributeError:
        pass
    return s

def setupDatabase(conn, tableFile):

    print("Resetting database...", flush=True)
    # LOKALER DATEIPFAD FÜR DATENBANK-RESET
    sqlFileName = "Awf_DB_Reset.sql" # lokal vorhanden

    # Tabellenblätter einlesen und auswerten
    if tableFile:
        print("Table for initial data found...", flush=True)
        awfFile = pd.ExcelFile(tableFile.read())

        awfSheetNames = [
            "filtersystematik", 
            "klassifikationssystematik", 
            "klassifikation", 
            "datei",
            "anwendungsfall", 
            "match_awf_klassifikation",
            "verantwortlichkeit", 
            "in_output",
            "aufgabe", 
            "aufgabe_auspraegung",
            "ivs", 
            "ivs_auspraegung", 
            "match_awf_aufgabe_auspraegung",
            "match_aufgabe_ausp_inoutput" #, 
            # "universaltype", 
            # "datenobjekt", 
            # "log", 
            # "merkmal", 
            # "informationscontainer", 
            # "match_aufgabe_log", 
            # "match_aufgabe_merkmal", 
            # "match_aufgabe_container"
        ]
        awfDataFrames = getDataFrameList(awfFile, awfSheetNames)
        print("Awf Sheets:", len(awfDataFrames), file=sys.stderr)

        # Tabellen nacheinander abrufen und Daten verknüpfen
        tables = {}

        for sheetName, df in zip(awfSheetNames, awfDataFrames): # DataFrames
            print("sheetName=", sheetName, file=sys.stderr)
            print(df.head(3), file=sys.stderr)

            # Dataframe aufbereiten
            # Spalten mit Namen "Unnamed" entfernen
            # print(df.columns.str.match("Unnamed"), file=sys.stderr)
            df = df.loc[:,~df.columns.str.match("Unnamed")] # ~ does bitwise negation
            # Leere Zeilen entfernen
            if sheetName.startswith("Match_"):
                df = df.dropna(axis="index", how="any") # Match-Tabellen müssen vollständige Zeilen haben
            else:
                df = df.dropna(axis="index", how="all")

            # print("Bereinigt:", file=sys.stderr)
            # print(df.head(3), file=sys.stderr)
            # print("", file=sys.stderr)

            # Alle Tabellenblätter werden mit ihren Spalten (keys) übernommen
            tables[sheetName] = list()
            for j in range(len(df)): # rows
                entry = {}
                invalidRow = False
                for key, dtype in zip(df.columns, df.dtypes): # cols
                    # print("key:", key, file=sys.stderr)
                    item = getDfItem(df, sheetName, j, key)
                    # Binäre Daten können nicht aus Tabelle geladen werden und werden übersprungen
                    if sheetName == "datei" and key == "datei":
                        continue
                    # Check ob Datensatz brauchbar                    
                    if item is None or (dtype in ("int64", "float64") and pd.isna(item)):
                        # print("itemcheck:", item is None, ",", dtype in ("int64", "float64"), ",",  pd.isna(item), file=sys.stderr)
                        if key in ("id", "code"): # Match-Tabellen müssen vollständige Zeilen haben
                            invalidRow = True
                            break
                        elif key == "universal_type":
                            item = "nd"
                        else:
                            continue
                    if key in ("ist_global", "ist_standardisiert", "ist_input"): # Booleans
                        value = cleanStr(item) in (True, 1, "1", "true", "True", "wahr", "Wahr")
                        # print(key, ":", item, cleanStr(item), value, file=sys.stderr)
                    elif dtype == "object":
                        value = cleanStr(item)
                    else:
                        value = item
                    entry[key] = value
                if invalidRow:
                    print(sheetName, "Zeile", j, "hat keine ID. Übersprungen.", file=sys.stderr)
                    invalidRow = False
                    continue # Zeile mit ungültigem Datensatz überspringen
                tables[sheetName].append(entry)

        for name in tables:
            print(name, ":", file=sys.stderr)
            print(tables[name], file=sys.stderr)
            print("", file=sys.stderr)


    '''
    Datenbankverbindung aufbauen und Tabellen initialisieren
    '''
    cursor = conn.cursor()
    # Encoding prüfen (UTF8/Unicode)
    cursor.execute("SHOW SERVER_ENCODING;")
    encServer = cursor.fetchone()[0]
    print("Server Encoding:", encServer)
    print("Client Encoding:", conn.encoding)
    if encServer != conn.encoding:
        print("Warnung: Server und Client Encoding stimmen nicht überein!")

    # Datenbanktabellen löschen und neue leere Tabellen erstellen
    sqlFile = open(sqlFileName, "r")
    cursor.execute(sqlFile.read())
    conn.commit()
    print("Datenbank zurückgesetzt.")
    cursor.close()

    '''
    Tabellendaten in Datenbank übertragen
    '''
    if tableFile:
        cursor = conn.cursor()
        tableNames = [str(name) for name in tables.keys()]
        for name in tableNames:
            print(name, ":")
            table = tables[name]
            for entry in table:
                print(entry)
                keyStr = ""
                valList = list()
                phStr = "" # placeholder for values
                first = True
                for key in entry:
                    # String der keys und Liste der values zusammenbauen
                    if first:
                        keyStr += key
                        phStr += "%s"
                        first = False
                    else:
                        keyStr += ", " + str(key)
                        phStr += ", %s"
                    valList.append(entry[key])
                # Listen an DB übergeben
                sql = "INSERT INTO " + name + " (" + keyStr + ") VALUES (" + phStr + ")"
                # print(sql)
                cursor.execute(sql, valList)
            print("Tabelle", name, "eingefügt.")
        # Daten übergeben
        conn.commit()
        cursor.close()

