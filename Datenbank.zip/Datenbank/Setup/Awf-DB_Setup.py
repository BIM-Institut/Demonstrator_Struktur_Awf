import urllib.request # file downloads
import psycopg2 # db connection
import pandas as pd # data frames + install openpyxl package
import numpy as np # stuff
import time
import os
from psycopg2.extensions import register_adapter, AsIs
psycopg2.extensions.register_adapter(np.int64, psycopg2._psycopg.AsIs)

# Einlesen der Tabellenblätter eines Exceldokuments
def getDataFrameList(filePath, sheetNames):
    dfList = list()
    for sheetName in sheetNames:
        dataFrame = pd.read_excel(filePath, sheet_name = sheetName)
        dfList.append(dataFrame)
        # print(dataFrame.head())
    return dfList

#
def getDfItem(df, sourceName, row, key):
    try: # KeyError: '400' -> Keine Spalte mit dieser Bezeichnung vorhanden
        item = df.loc[row, key]
        return item
    except KeyError:
        print("ERROR: Bei Tabellenblatt", sourceName, "fehlt Spaltenbezeichnung", key)

# Pairings von ID mit Liste von semikolon-getrennten IDs bauen
def getMatchList(id1, refStr):
    matchList = list()
    if refStr:
        if type(refStr) == str and ";" in refStr:
            refList = item.split(";")
        else: 
            refList = [refStr]

        for ref in refList:
            match = (id1, int(ref))
            matchList.append(match)
    return matchList

# Überzählige Leerzeichen, Umbrüche etc in String entfernen
def cleanStr(s):
    try:
        s = " ".join(s.split()) # removes "all whitespace characters (space, tab, newline, return, formfeed)" 
        # s = s.strip() # Leerzeichen, Tabs, Umbrüche am Anfang und Ende entfernen
        # s = s.replace("  ", " ") # Doppelte Leerzeichen reduzieren
        # s = s.replace("\t", " ") # Doppelte Leerzeichen reduzieren
        # s = s.replace("- \n", "") # Umbrüche im Wort entfernen
        # s = s.replace("-\n", "") # Umbrüche im Wort entfernen
        # s = s.replace("\n", "") # Verbleibende Umbrüche entfernen
    except AttributeError:
        pass
    return s

# Prüft die Verfügbarkeit einer Webresource
def online(host='http://example.com'):
    try:
        urllib.request.urlopen(host)
        return True
    except:
        return False

'''
Eingangsdaten aus config.txt lesen
'''
# LOKALER DATEIPFAD FÜR DATENBANK-RESET (NICHT ÄNDERN!)
sqlFileName = "Awf-DB_Reset.sql" # lokal vorhanden

# Dateinamen für DB-Input-Tabellen
awfFileName = "Awf-DB_Data.xlsm"

# Config lesen
configFilePath = 'config.txt'
url = "" # local files unless url is specified
with open(configFilePath, encoding='utf8') as f:
    for line in f:
        i = line.find("=")+1 # Startindex von Wert
        if "dbname=" in line:
            dbname = line[i:].strip()
        elif "user=" in line:
            user = line[i:].strip()
        elif "password=" in line:
            password = line[i:].strip()
        elif "url=" in line:
            url = line[i:].strip()
        else:
            continue
if dbname is None or user is None or password is None:
    configRead = False
    print("FEHLER! Config.txt konnte nicht gelesen werden.")
else:
    configRead = True
    print("Config.txt Datei gelesen.")

print("Download und Verarbeitung der Datentabellen gestartet...")
awfFilePath = url + awfFileName 
if not url:
    allFilesAvailable = True
else:
    allFilesAvailable = online(awfFilePath)

if configRead and allFilesAvailable:

    '''
    Tabellenblätter einlesen und auswerten
    '''
    awfFile = pd.ExcelFile(awfFilePath)
    # awfSheetNames = awfFile.sheet_names
    # Namen der Blätter und Spalten aus Tabelle
    # awfSheetNamesAndFlags = {
    #     "Filtersystematik": True, 
    #     "Klassifikationssystematik": True, 
    #     "Klassifikation": True, 
    #     "Datei": True,
    #     "Anwendungsfall": True, 
    #     "Match_Awf_Klassifikation": True,
    #     "Verantwortlichkeit": True, 
    #     "IVS": True, 
    #     "IVS_Auspraegung": True, 
    #     "Aufgabe": True, 
    #     "Aufgabe_Auspraegung": True,
    #     "Match_Awf_Aufgabe_Auspraegung": True,
    #     "Match_Aufgabe_Auspraegung_In_Output": True #, 
    #     # "UniversalType": True, 
    #     # "Datenobjekt": True, 
    #     # "Log": True, 
    #     # "Merkmal": True, 
    #     # "Informationscontainer": True, 
    #     # "Match_Aufgabe_Log": True, 
    #     # "Match_Aufgabe_Merkmal": True, 
    #     # "Match_Aufgabe_Container": True
    # }

    awfSheetNames = [
        "Filtersystematik", 
        "Klassifikationssystematik", 
        "Klassifikation", 
        "Datei",
        "Anwendungsfall", 
        "Match_Awf_Klassifikation",
        "Verantwortlichkeit", 
        "In_Output",
        "Aufgabe", 
        "Aufgabe_Auspraegung",
        "IVS", 
        "IVS_Auspraegung", 
        "Match_Awf_Aufgabe_Auspraegung",
        "Match_Aufgabe_Ausp_InOutput" #, 
        # "UniversalType", 
        # "Datenobjekt", 
        # "Log", 
        # "Merkmal", 
        # "Informationscontainer", 
        # "Match_Aufgabe_Log", 
        # "Match_Aufgabe_Merkmal", 
        # "Match_Aufgabe_Container"
    ]
    awfDataFrames = getDataFrameList(awfFile, awfSheetNames)
    print("Awf Sheets:", len(awfDataFrames))

    # Tabellen nacheinander abrufen und Daten verknüpfen
    tables = {}

    for sheetName, df in zip(awfSheetNames, awfDataFrames): # DataFrames
        print("sheetName=", sheetName)
        print(df.head(3))

        # Dataframe aufbereiten
        # Spalten mit Namen "Unnamed" entfernen
        # print(df.columns.str.match("Unnamed"))
        df = df.loc[:,~df.columns.str.match("Unnamed")] # ~ does bitwise negation
        # Leere Zeilen entfernen
        if sheetName.startswith("Match_"):
            df = df.dropna(axis="index", how="any") # Match-Tabellen müssen vollständige Zeilen haben
        else:
            df = df.dropna(axis="index", how="all")

        # print("Bereinigt:")
        # print(df.head(3))
        # print()

        # Alle Tabellenblätter bis auf "Anwendungsfall" (Flag=False) werden mit ihren Spalten (keys) übernommen
        # if awfSheetNamesAndFlags[sheetName]:
        tables[sheetName] = list()
        for j in range(len(df)): # rows
            entry = {}
            invalidRow = False
            for key, dtype in zip(df.columns, df.dtypes): # cols
                # print("key:", key)
                # if "Unnamed" in key: # Leere Spalten abfangen
                #     continue
                item = getDfItem(df, sheetName, j, key)
                # Check ob Datensatz brauchbar
                if item is None or (dtype in ("int64", "float64") and pd.isna(item)):
                # if item is None:
                    # print("itemcheck:", item is None, ",", dtype in ("int64", "float64"), ",",  pd.isna(item))
                    if key in ("id", "code"): # Match-Tabellen müssen vollständige Zeilen haben
                        invalidRow = True
                        break
                    elif key == "universal_type":
                        item = "nd"
                    else:
                        continue
                if key in ("ist_global", "ist_standardisiert", "ist_input"): # Booleans
                    value = cleanStr(item) in (True, 1, "1", "true", "True", "wahr", "Wahr")
                    # print(key, ":", item, cleanStr(item), value)
                elif dtype == "object":
                    value = cleanStr(item)
                else:
                    value = item
                entry[key] = value
            if invalidRow:
                print(sheetName, "Zeile", j, "hat keine ID. Übersprungen.")
                invalidRow = False
                continue # Zeile mit ungültigem Datensatz überspringen
            tables[sheetName].append(entry)

        # elif sheetName == "Anwendungsfall": 
        #     tables[sheetName] = list()
        #     tables["Match_Awf_Klassifikation"] = list()
        #     tables["Match_Awf_Aufgabe"] = list()
        #     for j in range(len(df)): # rows
        #         entry = {}
        #         matchEntries = list()
        #         invalidRow = False
        #         for key, dtype in zip(df.columns, df.dtypes): # cols
        #             # print("key=", key)
        #             # if "Unnamed" in key: # Leere Spalten abfangen
        #             #     continue
        #             item = getDfItem(df, sheetName, j, key)
        #             # Check ob Datensatz brauchbar
        #             if item is None or (dtype in ("int64", "float64") and pd.isna(item)):
        #                 if key == "id":
        #                     invalidRow = True
        #                     break
        #                 if key in ("abgrenzung", "voraussetzung"):
        #                     item = "Keine."
        #                 else:
        #                     continue
        #             if key == "klassifikationsliste": 
        #                 if not pd.isna(item): # NaN is empty entry
        #                     matchList = getMatchList(entry["id"], item)
        #                     if "Match_Awf_Klassifikation" in tables:
        #                         tables["Match_Awf_Klassifikation"].extend(matchList)
        #                     else:
        #                         tables["Match_Awf_Klassifikation"] = matchList
        #             elif key == "aufgabenauspraegungsliste":
        #                 if not pd.isna(item): # NaN is empty entry
        #                     matchList = getMatchList(entry["id"], item)
        #                     if "Match_Awf_Aufgabe" in tables:
        #                         tables["Match_Awf_Aufgabe"].extend(matchList)
        #                     else:
        #                         tables["Match_Awf_Aufgabe"] = matchList
        #             else:
        #                 value = cleanStr(item)
        #                 entry[key] = value
        #         if invalidRow:
        #             print(sheetName, "Zeile", j, "hat keine ID. Übersprungen.")
        #             invalidRow = False
        #             continue # Zeile mit ungültigem Datensatz überspringen
        #         tables[sheetName].append(entry)

    for name in tables:
        print(name, ":")
        print(tables[name])
        print()


    '''
    Datenbankverbindung aufbauen und Tabellen initialisieren
    '''
    try:
        conn = psycopg2.connect(dbname=dbname, user=user, host='localhost', password=password)
        print("Verbindung zur Datenbank aufgebaut.")
    except:
        print("Fehler: Konnte keine Verbindung zur Datenbank aufbauen!")

    cursor = conn.cursor()
    # Encoding prüfen (UTF8/Unicode)
    cursor.execute("SHOW SERVER_ENCODING;")
    encServer = cursor.fetchone()[0]
    print("Server Encoding:", encServer)
    print("Client Encoding:", conn.encoding)
    if encServer != conn.encoding:
        print("Warnung: Server und Client Encoding stimmen nicht überein!")

    # Datenbanktabellen löschen und neue leere Tabellen erstellen
    sqlFile = open(sqlFileName, "r")
    cursor.execute(sqlFile.read())
    conn.commit()
    print("Datenbank zurückgesetzt.")
    cursor.close()

    '''
    Tabellendaten in Datenbank übertragen
    '''
    cursor = conn.cursor()

    tableNames = [str(name) for name in tables.keys()]
    # tableNames.append(tableNames.pop(tableNames.index("Match_Awf_Aufgabe_Auspraegung")))
    for name in tableNames:
        print(name, ":")
        table = tables[name]

        # if name == "Match_Awf_Klassifikation":
        #     for matchTuple in table:
        #         # print(matchTuple)
        #         # Listen an DB übergeben
        #         sql = "INSERT INTO Match_Awf_Klassifikation (awf, klassifikation) VALUES (%s, %s)"
        #         # print(sql)
        #         cursor.execute(sql, matchTuple)

        # if name == "Match_Awf_Aufgabe_Auspraegung":
        #     for matchTuple in table:
        #         # print(matchTuple)
        #         # Listen an DB übergeben
        #         sql = "INSERT INTO Match_Awf_Klassifikation (id_anwendungsfall, id_aufgabe_auspraegung) VALUES (%s, %s)"
        #         # print(sql)
        #         cursor.execute(sql, matchTuple)

        # elif name == "Match_Aufgabe_Ausp_InOutput":
        #     for matchTuple in table:
        #         # print(matchTuple)
        #         # Listen an DB übergeben
        #         sql = "INSERT INTO Match_Awf_Aufgabe (id_aufgabe_auspraegung, id_in_output, ist_input) VALUES (%s, %s, %s)"
        #         # print(sql)
        #         cursor.execute(sql, matchTuple)

        # else:
        for entry in table:
            print(entry)
            keyStr = ""
            valList = list()
            phStr = "" # placeholder for values
            first = True
            for key in entry:
                # String der keys und Liste der values zusammenbauen
                if first:
                    keyStr += key
                    phStr += "%s"
                    first = False
                else:
                    keyStr += ", " + str(key)
                    phStr += ", %s"
                valList.append(entry[key])
            # Listen an DB übergeben
            sql = "INSERT INTO " + name + " (" + keyStr + ") VALUES (" + phStr + ")"
            # print(sql)
            cursor.execute(sql, valList)

        print("Tabelle", name, "eingefügt.")

    # Daten übergeben
    conn.commit()
    cursor.close()
    print("Daten in Datenbank übertragen.")

    # Verbindung zur Datenbank schließen
    conn.close()
    print("Datenbankverbindung geschlossen.")
    print("Datenbank wurde aktualisiert.")

elif not configRead:
    print("Datenbank wurde nicht aktualisiert.")
else:
    print("Dateien konnten nicht von Server abgerufen werden. Bitte überprüfen Sie Ihre Internetverbindung. Oder unsere...")
    print("Datenbank wurde nicht aktualisiert.")

print("Fenster schließt sich automatisch...")
time.sleep(10)
