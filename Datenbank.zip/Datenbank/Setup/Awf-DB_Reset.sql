DROP TABLE IF EXISTS
  Filtersystematik,
  Klassifikationssystematik,
  Klassifikation,
  Datei,
  Anwendungsfall,
  Match_Awf_Klassifikation,
  Verantwortlichkeit,
  In_Output,
  Aufgabe,
  Aufgabe_Auspraegung,
  IVS,
  IVS_Auspraegung,
  Match_Awf_Aufgabe_Auspraegung,
  Match_Aufgabe_Ausp_InOutput,
  -- UniversalType,
  -- Datenobjekt,
  -- Log,
  -- Match_Aufgabe_Log,
  -- Merkmal,
  -- Match_Aufgabe_Merkmal,
  -- Informationscontainer,
  -- Match_Aufgabe_Container,
  Matching  CASCADE;


SET client_encoding = UTF8;
SHOW client_encoding;

-- TABELLEN ERZEUGEN --

CREATE TABLE Filtersystematik (
  id SERIAL PRIMARY KEY,
  bezeichnung TEXT NOT NULL
);

CREATE TABLE Klassifikationssystematik (
  id SERIAL PRIMARY KEY,
  bezeichnung TEXT NOT NULL,
  ist_global BOOLEAN NOT NULL,
  id_filtersystematik INT REFERENCES Filtersystematik(id) NOT NULL
);

CREATE TABLE Klassifikation (
  id SERIAL PRIMARY KEY,
  bezeichnung TEXT NOT NULL,
  id_klassifikationssystematik INT REFERENCES Klassifikationssystematik(id) NOT NULL,
  id_global INT REFERENCES Klassifikation(id)
);

CREATE TABLE Datei (
  id SERIAL PRIMARY KEY,
  bezeichnung TEXT NOT NULL,
  url TEXT,
  datei BYTEA,
  dateityp TEXT
);

CREATE TABLE Anwendungsfall (
  id SERIAL PRIMARY KEY,
  bezeichnung TEXT NOT NULL,
  beschreibung TEXT NOT NULL,
  inputs TEXT NOT NULL,
  outputs TEXT NOT NULL,
  abgrenzung TEXT NOT NULL, -- Überprüfen ob Inhalt geliefert wird
  voraussetzung TEXT NOT NULL, -- Überprüfen
  id_loindatei INT REFERENCES Datei(id),
  pruefbeschreibung TEXT,
  id_pruefdatei INT REFERENCES Datei(id),
  id_prozessdiagramm INT REFERENCES Datei(id),
  id_interaktionsplan INT REFERENCES Datei(id),
  id_transaktionsdiagramm INT REFERENCES Datei(id)
);

CREATE TABLE Match_Awf_Klassifikation (
  id_anwendungsfall INT REFERENCES Anwendungsfall(id),
  id_klassifikation INT REFERENCES Klassifikation(id),
  PRIMARY KEY(id_anwendungsfall, id_klassifikation)
);

CREATE TABLE Verantwortlichkeit (
  id SERIAL PRIMARY KEY,
  bezeichnung TEXT NOT NULL
);

CREATE TABLE In_Output (
  id SERIAL PRIMARY KEY,
  bezeichnung TEXT NOT NULL,
  beschreibung TEXT
);

CREATE TABLE Aufgabe (
  id SERIAL PRIMARY KEY,
  bezeichnung TEXT NOT NULL
);

CREATE TABLE Aufgabe_Auspraegung (
  id SERIAL PRIMARY KEY,
  id_aufgabe INT REFERENCES Aufgabe(id) NOT NULL,
  id_verantwortlichkeit INT REFERENCES Verantwortlichkeit(id),
  mitgelt_dokumente TEXT
);

-- Informationsverarbeitungsschritt
CREATE TABLE IVS (
  id SERIAL PRIMARY KEY,
  bezeichnung TEXT NOT NULL
);

CREATE TABLE IVS_Auspraegung (
  id SERIAL PRIMARY KEY,
  id_ivs INT REFERENCES IVS(id) NOT NULL,
  bim_auspraegung TEXT NOT NULL,
  beschreibung TEXT NOT NULL,
  id_aufgabe_auspraegung INT REFERENCES Aufgabe_Auspraegung(id)
);

CREATE TABLE Match_Awf_Aufgabe_Auspraegung (
  id_anwendungsfall INT REFERENCES Anwendungsfall(id),
  id_aufgabe_auspraegung INT REFERENCES Aufgabe_Auspraegung(id),
  PRIMARY KEY(id_anwendungsfall, id_aufgabe_auspraegung)
);

CREATE TABLE Match_Aufgabe_Ausp_InOutput (
  id_aufgabe_auspraegung INT REFERENCES Aufgabe_Auspraegung(id),
  id_in_output INT REFERENCES In_Output(id),
  ist_input BOOLEAN NOT NULL,
  PRIMARY KEY(id_aufgabe_auspraegung, id_in_output)
);

-- CREATE TABLE UniversalType (
--   code TEXT PRIMARY KEY,
--   bezeichnung TEXT NOT NULL,
--   beschreibung TEXT
-- );

-- CREATE TABLE Datenobjekt (
--   id SERIAL PRIMARY KEY,
--   bezeichnung TEXT NOT NULL,
--   universal_type TEXT REFERENCES UniversalType(code)
-- );

-- CREATE TABLE Log (
--   id SERIAL PRIMARY KEY,
--   datenobjekt INT REFERENCES Datenobjekt(id) NOT NULL,
--   level INT NOT NULL,
--   beschreibung TEXT,
--   ist_standardisiert BOOLEAN NOT NULL -- true -> kommt aus BUW-MRL
-- );

-- CREATE TABLE Match_Aufgabe_Log (
--   aufgabe_auspraegung INT REFERENCES Aufgabe_Auspraegung(id) NOT NULL,
--   datenobjekt INT REFERENCES Datenobjekt(id) NOT NULL,
--   log INT REFERENCES Log(id) NOT NULL,
--   PRIMARY KEY(aufgabe_auspraegung, datenobjekt, log)
-- );

-- CREATE TABLE Merkmal (
--   id SERIAL PRIMARY KEY,
--   bezeichnung TEXT NOT NULL,
--   beschreibung TEXT NOT NULL,
--   universal_type TEXT REFERENCES UniversalType(code),
--   datenformat TEXT NOT NULL,
--   einheit TEXT NOT NULL
-- );

-- CREATE TABLE Match_Aufgabe_Merkmal (
--   aufgabe_auspraegung INT REFERENCES Aufgabe_Auspraegung(id) NOT NULL,
--   datenobjekt INT REFERENCES Datenobjekt(id) NOT NULL,
--   merkmal INT REFERENCES Merkmal(id) NOT NULL,
--   PRIMARY KEY(aufgabe_auspraegung, datenobjekt, merkmal)
-- );

-- CREATE TABLE Informationscontainer (
--   id SERIAL PRIMARY KEY,
--   bezeichnung TEXT NOT NULL,
--   beschreibung TEXT NOT NULL,
--   -- Dokument verknüpft oder mit binärem Datenformat einfügen?
--   dateiname TEXT,
--   datei BYTEA
-- );

-- CREATE TABLE Match_Aufgabe_Container (
--   aufgabe_auspraegung INT REFERENCES Aufgabe_Auspraegung(id) NOT NULL,
--   datenobjekt INT REFERENCES Datenobjekt(id) NOT NULL,
--   container INT REFERENCES Informationscontainer(id) NOT NULL,
--   PRIMARY KEY(aufgabe_auspraegung, datenobjekt, container)
-- );
